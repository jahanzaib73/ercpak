/*
-- Query: SELECT * FROM ict_administration.vehicle_types
LIMIT 0, 5000

-- Date: 2023-12-14 12:34
*/
INSERT INTO `` (`id`,`name`,`created_at`,`updated_at`,`deleted_at`,`location_id`) VALUES (1,'Motor Cycle','2020-02-14 00:01:28','2020-02-14 00:01:28',NULL,664);
INSERT INTO `` (`id`,`name`,`created_at`,`updated_at`,`deleted_at`,`location_id`) VALUES (2,'Motor Car','2020-02-14 00:01:28','2020-02-14 00:01:28',NULL,664);
INSERT INTO `` (`id`,`name`,`created_at`,`updated_at`,`deleted_at`,`location_id`) VALUES (3,'LTV','2020-02-14 00:01:28','2020-02-14 00:01:28',NULL,664);
INSERT INTO `` (`id`,`name`,`created_at`,`updated_at`,`deleted_at`,`location_id`) VALUES (4,'HTV','2020-02-14 00:01:28','2020-02-14 00:01:28',NULL,664);
INSERT INTO `` (`id`,`name`,`created_at`,`updated_at`,`deleted_at`,`location_id`) VALUES (5,'PSV','2020-02-14 00:01:28','2020-02-14 00:01:28',NULL,664);
INSERT INTO `` (`id`,`name`,`created_at`,`updated_at`,`deleted_at`,`location_id`) VALUES (6,'Not Defined','2019-12-07 05:00:00','2019-12-07 05:00:00',NULL,664);
