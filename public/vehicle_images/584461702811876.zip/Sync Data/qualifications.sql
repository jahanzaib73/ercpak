/*
-- Query: SELECT * FROM ict_administration.qualifications
LIMIT 0, 5000

-- Date: 2023-12-14 12:11
*/
INSERT INTO `` (`id`,`name`,`created_at`,`updated_at`,`deleted_at`) VALUES (1,'Primary','2019-12-12 18:49:27','2019-12-12 18:49:27',NULL);
INSERT INTO `` (`id`,`name`,`created_at`,`updated_at`,`deleted_at`) VALUES (2,'Middle','2019-12-12 18:49:27','2019-12-12 18:49:27',NULL);
INSERT INTO `` (`id`,`name`,`created_at`,`updated_at`,`deleted_at`) VALUES (3,'SSC','2019-12-12 18:49:27','2019-12-12 18:49:27',NULL);
INSERT INTO `` (`id`,`name`,`created_at`,`updated_at`,`deleted_at`) VALUES (4,'HSSC','2019-12-12 18:49:27','2019-12-12 18:49:27',NULL);
INSERT INTO `` (`id`,`name`,`created_at`,`updated_at`,`deleted_at`) VALUES (5,'Bachelors','2019-12-12 18:49:28','2019-12-12 18:49:28',NULL);
INSERT INTO `` (`id`,`name`,`created_at`,`updated_at`,`deleted_at`) VALUES (6,'Masters','2019-12-12 18:49:28','2019-12-12 18:49:28',NULL);
INSERT INTO `` (`id`,`name`,`created_at`,`updated_at`,`deleted_at`) VALUES (7,'PhD','2019-12-12 18:49:28','2019-12-12 18:49:28',NULL);
INSERT INTO `` (`id`,`name`,`created_at`,`updated_at`,`deleted_at`) VALUES (8,'Not Available','2019-12-12 18:49:28','2019-12-12 18:49:28',NULL);
INSERT INTO `` (`id`,`name`,`created_at`,`updated_at`,`deleted_at`) VALUES (9,'Other',NULL,NULL,NULL);
INSERT INTO `` (`id`,`name`,`created_at`,`updated_at`,`deleted_at`) VALUES (10,'Islamic Education',NULL,NULL,NULL);
