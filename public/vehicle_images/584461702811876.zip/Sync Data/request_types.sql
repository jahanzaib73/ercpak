/*
-- Query: SELECT * FROM ict_administration.request_types
LIMIT 0, 5000

-- Date: 2023-12-14 12:12
*/
INSERT INTO `` (`id`,`application_type_id`,`name`,`created_at`,`updated_at`,`deleted_at`) VALUES (1,NULL,'New','2020-02-14 00:01:28','2020-02-14 00:01:28',NULL);
INSERT INTO `` (`id`,`application_type_id`,`name`,`created_at`,`updated_at`,`deleted_at`) VALUES (2,NULL,'Duplicate','2020-02-14 00:01:28','2020-02-14 00:01:28',NULL);
INSERT INTO `` (`id`,`application_type_id`,`name`,`created_at`,`updated_at`,`deleted_at`) VALUES (3,NULL,'Revised','2020-02-14 00:01:28','2020-02-14 00:01:28',NULL);
INSERT INTO `` (`id`,`application_type_id`,`name`,`created_at`,`updated_at`,`deleted_at`) VALUES (4,NULL,'Replacement',NULL,NULL,NULL);
INSERT INTO `` (`id`,`application_type_id`,`name`,`created_at`,`updated_at`,`deleted_at`) VALUES (5,NULL,'Renewal',NULL,NULL,NULL);
INSERT INTO `` (`id`,`application_type_id`,`name`,`created_at`,`updated_at`,`deleted_at`) VALUES (6,NULL,'Change of Weapon',NULL,NULL,NULL);
INSERT INTO `` (`id`,`application_type_id`,`name`,`created_at`,`updated_at`,`deleted_at`) VALUES (7,NULL,'Change of Bore',NULL,NULL,NULL);
INSERT INTO `` (`id`,`application_type_id`,`name`,`created_at`,`updated_at`,`deleted_at`) VALUES (8,NULL,'Increase of Bullets',NULL,NULL,NULL);
INSERT INTO `` (`id`,`application_type_id`,`name`,`created_at`,`updated_at`,`deleted_at`) VALUES (9,NULL,'Extension of Coverage',NULL,NULL,NULL);
INSERT INTO `` (`id`,`application_type_id`,`name`,`created_at`,`updated_at`,`deleted_at`) VALUES (10,NULL,'Provisional',NULL,NULL,NULL);
