/*
-- Query: SELECT * FROM ict_administration.passport_types
LIMIT 0, 5000

-- Date: 2023-12-14 12:35
*/
INSERT INTO `` (`id`,`name`,`created_at`,`updated_at`,`deleted_at`) VALUES (1,'Diplomatic','2020-02-14 00:01:28','2020-02-14 00:01:28',NULL);
INSERT INTO `` (`id`,`name`,`created_at`,`updated_at`,`deleted_at`) VALUES (2,'Service/Official','2020-02-14 00:01:28','2020-02-14 00:01:28',NULL);
INSERT INTO `` (`id`,`name`,`created_at`,`updated_at`,`deleted_at`) VALUES (3,'Regular','2020-02-14 00:01:28','2020-02-14 00:01:28',NULL);
INSERT INTO `` (`id`,`name`,`created_at`,`updated_at`,`deleted_at`) VALUES (4,'Others','2019-12-06 05:00:00','2019-12-06 05:00:00',NULL);
