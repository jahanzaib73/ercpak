/*
-- Query: SELECT * FROM ict_administration.payment_types
LIMIT 0, 5000

-- Date: 2023-12-14 12:13
*/
INSERT INTO `` (`id`,`name`,`created_at`,`updated_at`,`deleted_at`,`location_id`) VALUES (1,'Cash','2020-02-14 00:01:28','2020-02-14 00:01:28',NULL,664);
INSERT INTO `` (`id`,`name`,`created_at`,`updated_at`,`deleted_at`,`location_id`) VALUES (2,'Manual - Through Challan','2020-02-14 00:01:28','2020-02-14 00:01:28',NULL,664);
INSERT INTO `` (`id`,`name`,`created_at`,`updated_at`,`deleted_at`,`location_id`) VALUES (3,'Esahulat','2020-02-14 00:01:28','2020-02-14 00:01:28',NULL,664);
INSERT INTO `` (`id`,`name`,`created_at`,`updated_at`,`deleted_at`,`location_id`) VALUES (4,'1Link',NULL,'2020-09-19 13:00:15',NULL,664);
