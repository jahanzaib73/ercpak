/*
-- Query: SELECT * FROM ict_administration.applicant_types
LIMIT 0, 5000

-- Date: 2023-12-14 12:08
*/
INSERT INTO `` (`id`,`name`,`application_type_id`,`created_at`,`updated_at`,`deleted_at`) VALUES (1,'Self',1,'2020-02-14 00:01:28','2020-02-14 00:01:28',NULL);
INSERT INTO `` (`id`,`name`,`application_type_id`,`created_at`,`updated_at`,`deleted_at`) VALUES (2,'Father',1,'2020-02-14 00:01:28','2020-02-14 00:01:28',NULL);
INSERT INTO `` (`id`,`name`,`application_type_id`,`created_at`,`updated_at`,`deleted_at`) VALUES (3,'Mother',1,'2020-02-14 00:01:28','2020-02-14 00:01:28',NULL);
INSERT INTO `` (`id`,`name`,`application_type_id`,`created_at`,`updated_at`,`deleted_at`) VALUES (4,'Son',1,'2020-02-14 00:01:28','2020-02-14 00:01:28',NULL);
INSERT INTO `` (`id`,`name`,`application_type_id`,`created_at`,`updated_at`,`deleted_at`) VALUES (5,'Daughter',1,'2020-02-14 00:01:28','2020-02-14 00:01:28',NULL);
INSERT INTO `` (`id`,`name`,`application_type_id`,`created_at`,`updated_at`,`deleted_at`) VALUES (6,'Husband',1,'2020-02-14 00:01:28','2020-02-14 00:01:28',NULL);
INSERT INTO `` (`id`,`name`,`application_type_id`,`created_at`,`updated_at`,`deleted_at`) VALUES (7,'Wife',1,'2020-02-14 00:01:28','2020-02-14 00:01:28',NULL);
INSERT INTO `` (`id`,`name`,`application_type_id`,`created_at`,`updated_at`,`deleted_at`) VALUES (8,'Other',1,NULL,NULL,NULL);
INSERT INTO `` (`id`,`name`,`application_type_id`,`created_at`,`updated_at`,`deleted_at`) VALUES (9,'Private Individual',8,NULL,NULL,NULL);
INSERT INTO `` (`id`,`name`,`application_type_id`,`created_at`,`updated_at`,`deleted_at`) VALUES (10,'Local Council',8,NULL,NULL,NULL);
INSERT INTO `` (`id`,`name`,`application_type_id`,`created_at`,`updated_at`,`deleted_at`) VALUES (11,'NGO',8,NULL,NULL,NULL);
INSERT INTO `` (`id`,`name`,`application_type_id`,`created_at`,`updated_at`,`deleted_at`) VALUES (12,'Previlige',8,NULL,NULL,NULL);
INSERT INTO `` (`id`,`name`,`application_type_id`,`created_at`,`updated_at`,`deleted_at`) VALUES (13,'Private Individual (Disabled)',8,NULL,NULL,NULL);
INSERT INTO `` (`id`,`name`,`application_type_id`,`created_at`,`updated_at`,`deleted_at`) VALUES (14,'Provincial Government',8,NULL,NULL,NULL);
INSERT INTO `` (`id`,`name`,`application_type_id`,`created_at`,`updated_at`,`deleted_at`) VALUES (15,'Semi Government',8,NULL,NULL,NULL);
INSERT INTO `` (`id`,`name`,`application_type_id`,`created_at`,`updated_at`,`deleted_at`) VALUES (16,'Company',8,NULL,NULL,NULL);
INSERT INTO `` (`id`,`name`,`application_type_id`,`created_at`,`updated_at`,`deleted_at`) VALUES (17,'Diplomat',8,NULL,NULL,NULL);
INSERT INTO `` (`id`,`name`,`application_type_id`,`created_at`,`updated_at`,`deleted_at`) VALUES (18,'Federal Government',8,NULL,NULL,NULL);
INSERT INTO `` (`id`,`name`,`application_type_id`,`created_at`,`updated_at`,`deleted_at`) VALUES (19,'Foreigner',8,NULL,NULL,NULL);
INSERT INTO `` (`id`,`name`,`application_type_id`,`created_at`,`updated_at`,`deleted_at`) VALUES (20,'Gretis',8,NULL,NULL,'2021-03-30 15:53:28');
