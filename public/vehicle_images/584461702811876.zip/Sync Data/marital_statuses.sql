/*
-- Query: SELECT * FROM ict_administration.marital_statuses
LIMIT 0, 5000

-- Date: 2023-12-14 12:10
*/
INSERT INTO `` (`id`,`name`,`deleted_at`) VALUES (1,'Single',NULL);
INSERT INTO `` (`id`,`name`,`deleted_at`) VALUES (2,'Married',NULL);
INSERT INTO `` (`id`,`name`,`deleted_at`) VALUES (3,'Divorced',NULL);
INSERT INTO `` (`id`,`name`,`deleted_at`) VALUES (4,'Widowed',NULL);
INSERT INTO `` (`id`,`name`,`deleted_at`) VALUES (5,'Widower',NULL);
