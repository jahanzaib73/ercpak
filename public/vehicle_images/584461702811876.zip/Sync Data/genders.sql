/*
-- Query: SELECT * FROM ict_administration.genders
LIMIT 0, 5000

-- Date: 2023-12-14 12:12
*/
INSERT INTO `` (`id`,`name`,`deleted_at`) VALUES (1,'Male',NULL);
INSERT INTO `` (`id`,`name`,`deleted_at`) VALUES (2,'Female',NULL);
INSERT INTO `` (`id`,`name`,`deleted_at`) VALUES (3,'Transgender',NULL);
