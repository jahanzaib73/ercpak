/*
-- Query: SELECT * FROM ict_administration.occupations
LIMIT 0, 5000

-- Date: 2023-12-14 12:11
*/
INSERT INTO `` (`id`,`name`,`created_at`,`updated_at`,`deleted_at`) VALUES (1,'Government Employee','2020-02-14 00:01:28','2020-02-14 00:01:28',NULL);
INSERT INTO `` (`id`,`name`,`created_at`,`updated_at`,`deleted_at`) VALUES (2,'Non Government Employee','2020-02-14 00:01:28','2020-02-14 00:01:28',NULL);
INSERT INTO `` (`id`,`name`,`created_at`,`updated_at`,`deleted_at`) VALUES (3,'Own Business','2020-02-14 00:01:28','2020-02-14 00:01:28',NULL);
INSERT INTO `` (`id`,`name`,`created_at`,`updated_at`,`deleted_at`) VALUES (4,'Student','2020-02-14 00:01:28','2020-02-14 00:01:28',NULL);
INSERT INTO `` (`id`,`name`,`created_at`,`updated_at`,`deleted_at`) VALUES (5,'Other','2020-02-14 00:01:28','2020-02-14 00:01:28',NULL);
INSERT INTO `` (`id`,`name`,`created_at`,`updated_at`,`deleted_at`) VALUES (6,'House wife',NULL,NULL,NULL);
INSERT INTO `` (`id`,`name`,`created_at`,`updated_at`,`deleted_at`) VALUES (7,'Private Job',NULL,NULL,NULL);
